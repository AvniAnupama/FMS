<?php
require_once"../../config/db_connect.php";
$obj=new db_connect;
$tableName="tbl_blog_blogs";
//print_r($_REQUEST);
if(isset($_REQUEST['Save']))
{
	unset($_REQUEST['Save']);
	if(!isset($_FILES['image']) || $_FILES['image']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['image']=$_REQUEST['image_file_dummy'];
	   unset($_REQUEST['image_file_dummy']);
		} else {
		
							$imgTp=$_FILES["image"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['image']['name'];
							$path="../blog/Files/";//folder name is users
							$img=$_FILES['image']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['image']=$pathname;
							if($_REQUEST['image_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['image_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['image']='';
							 
							}
		}
		unset($_REQUEST['image_file_dummy']);
	
	$result=$obj->inserttblReturnId($_REQUEST,$tableName);
	if($result>0)
   {
		header("location:../../public/blog-blogs?result=1");
	}
	else
	{
		header("location:../../public/blog-blogs?result=0");
	}
}
if(isset($_REQUEST['update']))
{
	$con=array('blog_blogs_id'=>$_REQUEST['update']);
	unset($_REQUEST['update']);
	if(!isset($_FILES['image']) || $_FILES['image']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['image']=$_REQUEST['image_file_dummy'];
	   unset($_REQUEST['image_file_dummy']);
		} else {
		
							$imgTp=$_FILES["image"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['image']['name'];
							$path="../blog/Files/";//folder name is users
							$img=$_FILES['image']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['image']=$pathname;
							if($_REQUEST['image_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['image_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['image']='';
							 
							}
		}
		unset($_REQUEST['image_file_dummy']);
	
	$result=$obj->updatetbl($_REQUEST,$tableName,$con);
	if($result>0)
	{
		header("location:../../public/blog-blogs?result=1");
	}
	else
	{
		header("location:../../public/blog-blogs?result=0");
	}
}
if(isset($_REQUEST['blog_blogs_id']))
{
	$condition="blog_blogs_id='".$_REQUEST['blog_blogs_id']."'";
	$oldDate=$obj->select_any_one($tableName,$condition);
	if($oldDate['image']!='')
	{
		unlink("../".$oldDate['image']);
	}
	$result=$obj->tbl_delete($tableName,$condition);
	if($result==1)
	{
		header("location:../../public/blog-blogs?result=1");
	}
	else
	{
		header("location:../../public/blog-blogs?result=0");
	}
}
?>