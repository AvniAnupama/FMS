		   <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="Home">Dashboard</a></li>
						<li class="breadcrumb-item"><a href="blog"><?=ucwords('blog');?></a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)"><?=ucwords('Blogs');?></a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->
			<div class="container-fluid">
				
				<div class="row">
					 <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><?=ucwords('Blogs');?></h4>
                                
                                <div class="basic-form" >
								
                                    <form enctype="multipart/form-data"  method="POST"  action="../blog/Action/Actionblog_blogs.php">
										<div id="UserFormUpdate">
										<?php
										if(isset($_GET['edit_id']))
										{
											$formDataEdit=$obj->select_any_one("tbl_blog_blogs","blog_blogs_id='".$_GET['edit_id']."'");
										}
										?>
										
<div class="form-group">
<label>category:</label>
<select  class="form-control input-default" name="category">
<option value="">Choose your option</option>
<?php
$category_data=$obj->select_any("tbl_blog_blog_category","1");
foreach($category_data as $category_data_single)
{
?>
<option <?=(isset($formDataEdit))?(($formDataEdit['category']==$category_data_single['blog_blog_category_id'])?'selected':''):'';?> value="<?=$category_data_single['blog_blog_category_id'];?>"><?=$category_data_single['category_name'];?></option>
<?php	
}
?>
</select>
</div>
<div class="form-group">
<label>image:</label>
<input <?=(isset($formDataEdit['image']))?'':'';?> accept="image/*" type="file" name="image"  class="form-control input-default">
<input type="hidden" name="image_file_dummy" value="<?=(isset($formDataEdit['image']))?$formDataEdit['image']:'';?>">
</div>
<div class="form-group">
<label>author:</label>
<input  type="text" name="author" value="<?=(isset($formDataEdit['author']))?$formDataEdit['author']:'';?>" class="form-control input-default">
</div>
<div class="form-group">
<label>title:</label>
<input  type="text" name="title" value="<?=(isset($formDataEdit['title']))?$formDataEdit['title']:'';?>" class="form-control input-default">
</div>
<div class="form-group">
<label>content:</label>
<textarea  name="content"  class="form-control input-default"><?=(isset($formDataEdit['content']))?$formDataEdit['content']:'';?></textarea>
</div>
<script>
CKEDITOR.replace( 'content' );
</script>
<div class="form-group">
<label>date:</label>
<input  value="<?=(isset($formDataEdit['date']))?$formDataEdit['date']:'';?>"  type="date" name="date"  class="form-control input-default">
</div>
										<?php
										if(isset($_GET['edit_id']))
										{
											?>
												<input type="hidden" value="<?=(isset($formDataEdit['blog_blogs_id']))?$formDataEdit['blog_blogs_id']:'';?>"  name="update">
									
											<?php
										}
										else
										{
											?>
												<input type="hidden" name="Save">
											<?php
										}
										?>
									</div>
									<button type="submit"  class="btn btn-dark">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
					
				</div>
				
				<div class="row">
						 <div class="col-lg-12">
						   <div class="card" style="overflow-x:auto;">
								<div class="card-body" id="UserTable">
									<h4 class="card-title">Table</h4>
										<table id="example" class="display nowrap" cellspacing="0" width="100%">
											<thead>
												<tr>
												<th>Si No</th>
													
<th>category</th>
<th>image</th>
<th>author</th>
<th>title</th>
<th>content</th>
<th>date</th><th>Edit</th>
<th>Delete</th>
												</tr>
											</thead>
											<tbody>
											<?php
											$formDataFull=$obj->select_any("tbl_blog_blogs","1 order by blog_blogs_id DESC");
											$count=1;
											if(!empty($formDataFull))
											{
											foreach($formDataFull as $formDataSingle)
											{
											
											?>
											<tr>
											<td><?=$count;?></th>
											
<?php
$category=$obj->select_any_one("tbl_blog_blog_category","blog_blog_category_id='".$formDataSingle['category']."'");
?>
<td><?=$category['category_name'];?></td>
<?php
if(!empty($formDataSingle['image']))
{
?>
<td><img src="<?=$formDataSingle['image'];?>" width="100px" height="100px"></td>
<?php
}
else
{
?>
<td><?=$formDataSingle['image'];?></td>
<?php
}
?>
<td><?=$formDataSingle['author'];?></td>
<td><?=$formDataSingle['title'];?></td>
<td><?=$formDataSingle['content'];?></td>
<td><?=$formDataSingle['date'];?></td>	<td><a href="?edit_id=<?=$formDataSingle['blog_blogs_id'];?>"><i class="fa fa-edit color-danger"></i></a></td>
	<td><a href="../blog/Action/Actionblog_blogs.php?blog_blogs_id=<?=$formDataSingle['blog_blogs_id'];?>"><i class="fa fa-close color-danger"></i></a></td>
											</tr>
											<?php
											$count++;
											}
											}
											?>
											</tbody>
										</table>

								</div>
							</div>
						</div>
				</div>
				
			</div>
            <!-- #/ container -->
        </div>
		
        <!--**********************************
            Content body end
        ***********************************--> 
		<script>
		var IndexIncrement=<?=count($formDataFull);?>
		</script>