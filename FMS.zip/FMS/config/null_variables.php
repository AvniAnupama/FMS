<?php
$include_style_to_head='';
$include_script_to_footer='';
?>