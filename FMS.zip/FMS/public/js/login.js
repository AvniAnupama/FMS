window.isSubmitted = false;
function CheckLogin(event)
{
	event.preventDefault();
		if(!window.isSubmitted)
		{
				    var data=$("#LoginForm").serializeArray();
					$.post($("#LoginForm").attr('action'),data,function(res){
						if(res == "1"){
							$("#loginSubmit").html("<i class='fa fa-spinner fa-spin'/>&nbsp;&nbsp;Done! Redirecting...");
							window.location.replace("Home");
						}
						else if(res == "2")
						{
							window.isSubmitted = false;
							$("#loginSubmit").html("Account has been blocked/Waiting for approval !");
							$("#loginSubmit").prop('disabled', false);
						}
						else
						{
							window.isSubmitted = false;
							$("#loginSubmit").html("Invalid User name or Password");
							$("#loginSubmit").prop('disabled', false);
						}
					});
					window.isSubmitted = true;
					$("#loginSubmit").html("<i class='fa fa-spinner fa-spin'/>&nbsp;&nbsp;Waiting for Network...")
					$("#loginSubmit").prop('disabled', true);
		}
}
	