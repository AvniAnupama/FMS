window.isSubmitted = false;
var table;
$(document).ready(function() {
	
    table=$('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );

$("form#form").submit(function(e) {
                e.preventDefault();    
                var formData = new FormData(this);
				var module_item= formData.get("module_item").trim();
				var moduleCaps=module_item.toUpperCase();
				var checkForPagename=moduleCaps.replace(" ","_");
				var KeyWords = ["ASSETS", "CONFIG", "FUNCTIONS","HOME", "LOGIN", "MODULE","PAGES", "PUBLIC", "SQL","TEMPLATES","USER","USER_MANAGEMENT","INDEX","LOGOUT"];
				if(jQuery.inArray(moduleCaps, KeyWords) !== -1)
				{
					swal(
                            'Failed!',
                            'you are using a keyword in module name please change it.Please change and re try',
                            'error'
                        );
						
				}
				else if(jQuery.inArray(checkForPagename, JqueryPageNameArray) !== -1)
				{
					swal(
                            'Failed!',
                            'in module name you are using a name that already exist in another module.Please change and re try',
                            'error'
                        );
						
				}
				else if(jQuery.inArray(moduleCaps, JqueryModuleNameArray) !== -1)
				{
					swal(
                            'Failed!',
                            'Module Already avaliable plese change module name or delete existing one..Please change and re try',
                            'error'
                        );
				}
				else
				{	
				
				var module_comments= formData.get("module_comments");
				$.ajax({
                    url: '../module/ActionModule.php',
                    type: 'POST',
                    data: formData,
					cache: false,
                    success: function (res) {
                        if(res >0){
							JqueryModuleNameArray.push(moduleCaps);
							window.isSubmitted = false;
							 swal(
                            'Done!',
                            'Status: Successfully Completed your process',
                            'success'
                        );
						$("#formSubmit").html("Submit");
						$("#formSubmit").prop('disabled', false);
						$("#form")[0].reset();
						var index=parseInt(res);
						index=index-1;
						var action='<a href="#" onclick="UserDelete('+index+');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fa fa-close color-danger"></i></a>';
						table.row.add([res, module_item, module_comments,action]).draw();
						}
						else{
							
							window.isSubmitted = false;
							$("#formSubmit").html("Failed! Try again");
							swal(
                            'Failed!',
                            'Status Please try again',
                            'error'
                        );
						
							$("#formSubmit").prop('disabled', false);

						}
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                });
				 window.isSubmitted = true;
					$("#formSubmit").html("<i class='fa fa-spinner fa-spin'/>&nbsp;&nbsp;Waiting for Network...");
					$("#formSubmit").prop('disabled', true);
			}
               
					
            });
} );
function UserEdit(val,name) {
	swal({
		  title: "Are you sure?",
		  text: "Do You Want to Edit this?",
		  icon: "info",
		  buttons: true,
		  dangerMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
		  var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + "?"+name+"="+val;
		  window.history.pushState({ path: newurl }, '', newurl);
		  $('#User_Form').load(document.URL + ' #User_Form');
		  newurl = window.location.protocol + "//" + window.location.host + window.location.pathname;
		  window.history.pushState({ path: newurl }, '', newurl);
		  $('html, body').animate({
			scrollTop: $("#ActionSection").offset().top
			}, 2000);
		  }
		   else {
			swal("Your imaginary file is not Edited!");
		  }
		});
		
		}

function UserDelete(val) {
			swal({
		  title: "Are you sure?",
		  text: "Once deleted, you will not be able to recover this imaginary file!",
		  icon: "warning",
		  buttons: true,
		  dangerMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
		$.ajax({
		type: "POST",
		url: "../module/ActionModule.php",
		data:{'index':val},
		success: function(res){
			if(res == "1"){
							
							 swal(
                            'Done!',
                            'Status: Successfully Completed your process',
                            'success'
                        )
						table.row(val).remove().draw();
						}
						else{
							window.isSubmitted = false;
							swal(
                            'Failed!',
                            'Status Please try again',
                            'error'
                        );
						}
		}
		});
		  } else {
			swal("Your imaginary file is safe!");
		  }
		});
	
}	
	