<?php
/***************************************************************************
* File name   : index.php
* Begin       : 12 April 2020
* Description : create module page
* Author: Anupama A
***************************************************************************/
include_once"../login/login.php";
?>