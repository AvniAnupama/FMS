		   <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="Home">Dashboard</a></li>
						<li class="breadcrumb-item"><a href="books"><?=ucwords('books');?></a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)"><?=ucwords('Books');?></a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->
			<div class="container-fluid">
				
				<div class="row">
					 <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><?=ucwords('Books');?></h4>
                                
                                <div class="basic-form" >
								
                                    <form enctype="multipart/form-data"  method="POST"  action="../books/Action/Actionbooks_books.php">
										<div id="UserFormUpdate">
										<?php
										if(isset($_GET['edit_id']))
										{
											$formDataEdit=$obj->select_any_one("tbl_books_books","books_books_id='".$_GET['edit_id']."'");
										}
										?>
										
<div class="form-group">
<label>thumbnail 1:</label>
<input <?=(isset($formDataEdit['thumbnail_1']))?'':'';?> accept="image/*" type="file" name="thumbnail_1"  class="form-control input-default">
<input type="hidden" name="thumbnail_1_file_dummy" value="<?=(isset($formDataEdit['thumbnail_1']))?$formDataEdit['thumbnail_1']:'';?>">
</div>
<div class="form-group">
<label>thumbnail 2:</label>
<input <?=(isset($formDataEdit['thumbnail_2']))?'':'';?> accept="image/*" type="file" name="thumbnail_2"  class="form-control input-default">
<input type="hidden" name="thumbnail_2_file_dummy" value="<?=(isset($formDataEdit['thumbnail_2']))?$formDataEdit['thumbnail_2']:'';?>">
</div>
<div class="form-group">
<label>thumbnail 3:</label>
<input <?=(isset($formDataEdit['thumbnail_3']))?'':'';?> accept="image/*" type="file" name="thumbnail_3"  class="form-control input-default">
<input type="hidden" name="thumbnail_3_file_dummy" value="<?=(isset($formDataEdit['thumbnail_3']))?$formDataEdit['thumbnail_3']:'';?>">
</div>
<div class="form-group">
<label>thumbnail 4:</label>
<input <?=(isset($formDataEdit['thumbnail_4']))?'':'';?> accept="image/*" type="file" name="thumbnail_4"  class="form-control input-default">
<input type="hidden" name="thumbnail_4_file_dummy" value="<?=(isset($formDataEdit['thumbnail_4']))?$formDataEdit['thumbnail_4']:'';?>">
</div>
<div class="form-group">
<label>main category:</label>
<select  class="form-control input-default" name="main_category">
<option value="">Choose your option</option>
<?php
$main_category_data=$obj->select_any("tbl_category_category","1");
foreach($main_category_data as $main_category_data_single)
{
?>
<option <?=(isset($formDataEdit))?(($formDataEdit['main_category']==$main_category_data_single['category_category_id'])?'selected':''):'';?> value="<?=$main_category_data_single['category_category_id'];?>"><?=$main_category_data_single['title'];?></option>
<?php	
}
?>
</select>
</div>
<div class="form-group">
<label>book category:</label>
<select  class="form-control input-default" name="book_category">
<option value="">Choose your option</option>
<?php
$book_category_data=$obj->select_any("tbl_books_book_category","1");
foreach($book_category_data as $book_category_data_single)
{
?>
<option <?=(isset($formDataEdit))?(($formDataEdit['book_category']==$book_category_data_single['books_book_category_id'])?'selected':''):'';?> value="<?=$book_category_data_single['books_book_category_id'];?>"><?=$book_category_data_single['category_name'];?></option>
<?php	
}
?>
</select>
</div>
<div class="form-group">
<label>book name:</label>
<input  type="text" name="book_name" value="<?=(isset($formDataEdit['book_name']))?$formDataEdit['book_name']:'';?>" class="form-control input-default">
</div>
<div class="form-group">
<label>book author:</label>
<input  type="text" name="book_author" value="<?=(isset($formDataEdit['book_author']))?$formDataEdit['book_author']:'';?>" class="form-control input-default">
</div>
<div class="form-group">
<label>description:</label>
<textarea  name="description"  class="form-control input-default"><?=(isset($formDataEdit['description']))?$formDataEdit['description']:'';?></textarea>
</div>
<script>
CKEDITOR.replace( 'description' );
</script>
										<?php
										if(isset($_GET['edit_id']))
										{
											?>
												<input type="hidden" value="<?=(isset($formDataEdit['books_books_id']))?$formDataEdit['books_books_id']:'';?>"  name="update">
									
											<?php
										}
										else
										{
											?>
												<input type="hidden" name="Save">
											<?php
										}
										?>
									</div>
									<button type="submit"  class="btn btn-dark">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
					
				</div>
				
				<div class="row">
						 <div class="col-lg-12">
						   <div class="card" style="overflow-x:auto;">
								<div class="card-body" id="UserTable">
									<h4 class="card-title">Table</h4>
										<table id="example" class="display nowrap" cellspacing="0" width="100%">
											<thead>
												<tr>
												<th>Si No</th>
													
<th>thumbnail 1</th>
<th>thumbnail 2</th>
<th>thumbnail 3</th>
<th>thumbnail 4</th>
<th>main category</th>
<th>book category</th>
<th>book name</th>
<th>book author</th>
<th>description</th><th>Edit</th>
<th>Delete</th>
												</tr>
											</thead>
											<tbody>
											<?php
											$formDataFull=$obj->select_any("tbl_books_books","1 order by books_books_id DESC");
											$count=1;
											if(!empty($formDataFull))
											{
											foreach($formDataFull as $formDataSingle)
											{
											
											?>
											<tr>
											<td><?=$count;?></th>
											
<?php
if(!empty($formDataSingle['thumbnail_1']))
{
?>
<td><img src="<?=$formDataSingle['thumbnail_1'];?>" width="100px" height="100px"></td>
<?php
}
else
{
?>
<td><?=$formDataSingle['thumbnail_1'];?></td>
<?php
}
?>
<?php
if(!empty($formDataSingle['thumbnail_2']))
{
?>
<td><img src="<?=$formDataSingle['thumbnail_2'];?>" width="100px" height="100px"></td>
<?php
}
else
{
?>
<td><?=$formDataSingle['thumbnail_2'];?></td>
<?php
}
?>
<?php
if(!empty($formDataSingle['thumbnail_3']))
{
?>
<td><img src="<?=$formDataSingle['thumbnail_3'];?>" width="100px" height="100px"></td>
<?php
}
else
{
?>
<td><?=$formDataSingle['thumbnail_3'];?></td>
<?php
}
?>
<?php
if(!empty($formDataSingle['thumbnail_4']))
{
?>
<td><img src="<?=$formDataSingle['thumbnail_4'];?>" width="100px" height="100px"></td>
<?php
}
else
{
?>
<td><?=$formDataSingle['thumbnail_4'];?></td>
<?php
}
?>
<?php
$main_category=$obj->select_any_one("tbl_category_category","category_category_id='".$formDataSingle['main_category']."'");
?>
<td><?=$main_category['title'];?></td>
<?php
$book_category=$obj->select_any_one("tbl_books_book_category","books_book_category_id='".$formDataSingle['book_category']."'");
?>
<td><?=$book_category['category_name'];?></td>
<td><?=$formDataSingle['book_name'];?></td>
<td><?=$formDataSingle['book_author'];?></td>
<td><?=$formDataSingle['description'];?></td>	<td><a href="?edit_id=<?=$formDataSingle['books_books_id'];?>"><i class="fa fa-edit color-danger"></i></a></td>
	<td><a href="../books/Action/Actionbooks_books.php?books_books_id=<?=$formDataSingle['books_books_id'];?>"><i class="fa fa-close color-danger"></i></a></td>
											</tr>
											<?php
											$count++;
											}
											}
											?>
											</tbody>
										</table>

								</div>
							</div>
						</div>
				</div>
				
			</div>
            <!-- #/ container -->
        </div>
		
        <!--**********************************
            Content body end
        ***********************************--> 
		<script>
		var IndexIncrement=<?=count($formDataFull);?>
		</script>