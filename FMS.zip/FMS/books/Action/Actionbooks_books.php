<?php
require_once"../../config/db_connect.php";
$obj=new db_connect;
$tableName="tbl_books_books";
//print_r($_REQUEST);
if(isset($_REQUEST['Save']))
{
	unset($_REQUEST['Save']);
	if(!isset($_FILES['thumbnail_1']) || $_FILES['thumbnail_1']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['thumbnail_1']=$_REQUEST['thumbnail_1_file_dummy'];
	   unset($_REQUEST['thumbnail_1_file_dummy']);
		} else {
		
							$imgTp=$_FILES["thumbnail_1"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['thumbnail_1']['name'];
							$path="../books/Files/";//folder name is users
							$img=$_FILES['thumbnail_1']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['thumbnail_1']=$pathname;
							if($_REQUEST['thumbnail_1_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['thumbnail_1_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['thumbnail_1']='';
							 
							}
		}
		unset($_REQUEST['thumbnail_1_file_dummy']);if(!isset($_FILES['thumbnail_2']) || $_FILES['thumbnail_2']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['thumbnail_2']=$_REQUEST['thumbnail_2_file_dummy'];
	   unset($_REQUEST['thumbnail_2_file_dummy']);
		} else {
		
							$imgTp=$_FILES["thumbnail_2"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['thumbnail_2']['name'];
							$path="../books/Files/";//folder name is users
							$img=$_FILES['thumbnail_2']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['thumbnail_2']=$pathname;
							if($_REQUEST['thumbnail_2_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['thumbnail_2_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['thumbnail_2']='';
							 
							}
		}
		unset($_REQUEST['thumbnail_2_file_dummy']);if(!isset($_FILES['thumbnail_3']) || $_FILES['thumbnail_3']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['thumbnail_3']=$_REQUEST['thumbnail_3_file_dummy'];
	   unset($_REQUEST['thumbnail_3_file_dummy']);
		} else {
		
							$imgTp=$_FILES["thumbnail_3"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['thumbnail_3']['name'];
							$path="../books/Files/";//folder name is users
							$img=$_FILES['thumbnail_3']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['thumbnail_3']=$pathname;
							if($_REQUEST['thumbnail_3_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['thumbnail_3_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['thumbnail_3']='';
							 
							}
		}
		unset($_REQUEST['thumbnail_3_file_dummy']);if(!isset($_FILES['thumbnail_4']) || $_FILES['thumbnail_4']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['thumbnail_4']=$_REQUEST['thumbnail_4_file_dummy'];
	   unset($_REQUEST['thumbnail_4_file_dummy']);
		} else {
		
							$imgTp=$_FILES["thumbnail_4"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['thumbnail_4']['name'];
							$path="../books/Files/";//folder name is users
							$img=$_FILES['thumbnail_4']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['thumbnail_4']=$pathname;
							if($_REQUEST['thumbnail_4_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['thumbnail_4_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['thumbnail_4']='';
							 
							}
		}
		unset($_REQUEST['thumbnail_4_file_dummy']);
	
	$result=$obj->inserttblReturnId($_REQUEST,$tableName);
	if($result>0)
   {
		header("location:../../public/books-books?result=1");
	}
	else
	{
		header("location:../../public/books-books?result=0");
	}
}
if(isset($_REQUEST['update']))
{
	$con=array('books_books_id'=>$_REQUEST['update']);
	unset($_REQUEST['update']);
	if(!isset($_FILES['thumbnail_1']) || $_FILES['thumbnail_1']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['thumbnail_1']=$_REQUEST['thumbnail_1_file_dummy'];
	   unset($_REQUEST['thumbnail_1_file_dummy']);
		} else {
		
							$imgTp=$_FILES["thumbnail_1"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['thumbnail_1']['name'];
							$path="../books/Files/";//folder name is users
							$img=$_FILES['thumbnail_1']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['thumbnail_1']=$pathname;
							if($_REQUEST['thumbnail_1_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['thumbnail_1_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['thumbnail_1']='';
							 
							}
		}
		unset($_REQUEST['thumbnail_1_file_dummy']);if(!isset($_FILES['thumbnail_2']) || $_FILES['thumbnail_2']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['thumbnail_2']=$_REQUEST['thumbnail_2_file_dummy'];
	   unset($_REQUEST['thumbnail_2_file_dummy']);
		} else {
		
							$imgTp=$_FILES["thumbnail_2"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['thumbnail_2']['name'];
							$path="../books/Files/";//folder name is users
							$img=$_FILES['thumbnail_2']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['thumbnail_2']=$pathname;
							if($_REQUEST['thumbnail_2_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['thumbnail_2_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['thumbnail_2']='';
							 
							}
		}
		unset($_REQUEST['thumbnail_2_file_dummy']);if(!isset($_FILES['thumbnail_3']) || $_FILES['thumbnail_3']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['thumbnail_3']=$_REQUEST['thumbnail_3_file_dummy'];
	   unset($_REQUEST['thumbnail_3_file_dummy']);
		} else {
		
							$imgTp=$_FILES["thumbnail_3"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['thumbnail_3']['name'];
							$path="../books/Files/";//folder name is users
							$img=$_FILES['thumbnail_3']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['thumbnail_3']=$pathname;
							if($_REQUEST['thumbnail_3_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['thumbnail_3_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['thumbnail_3']='';
							 
							}
		}
		unset($_REQUEST['thumbnail_3_file_dummy']);if(!isset($_FILES['thumbnail_4']) || $_FILES['thumbnail_4']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['thumbnail_4']=$_REQUEST['thumbnail_4_file_dummy'];
	   unset($_REQUEST['thumbnail_4_file_dummy']);
		} else {
		
							$imgTp=$_FILES["thumbnail_4"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['thumbnail_4']['name'];
							$path="../books/Files/";//folder name is users
							$img=$_FILES['thumbnail_4']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['thumbnail_4']=$pathname;
							if($_REQUEST['thumbnail_4_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['thumbnail_4_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['thumbnail_4']='';
							 
							}
		}
		unset($_REQUEST['thumbnail_4_file_dummy']);
	
	$result=$obj->updatetbl($_REQUEST,$tableName,$con);
	if($result>0)
	{
		header("location:../../public/books-books?result=1");
	}
	else
	{
		header("location:../../public/books-books?result=0");
	}
}
if(isset($_REQUEST['books_books_id']))
{
	$condition="books_books_id='".$_REQUEST['books_books_id']."'";
	$oldDate=$obj->select_any_one($tableName,$condition);
	if($oldDate['thumbnail_1']!='')
	{
		unlink("../".$oldDate['thumbnail_1']);
	}$oldDate=$obj->select_any_one($tableName,$condition);
	if($oldDate['thumbnail_2']!='')
	{
		unlink("../".$oldDate['thumbnail_2']);
	}$oldDate=$obj->select_any_one($tableName,$condition);
	if($oldDate['thumbnail_3']!='')
	{
		unlink("../".$oldDate['thumbnail_3']);
	}$oldDate=$obj->select_any_one($tableName,$condition);
	if($oldDate['thumbnail_4']!='')
	{
		unlink("../".$oldDate['thumbnail_4']);
	}
	$result=$obj->tbl_delete($tableName,$condition);
	if($result==1)
	{
		header("location:../../public/books-books?result=1");
	}
	else
	{
		header("location:../../public/books-books?result=0");
	}
}
?>