<?php
/***************************************************************************
*  Objective: used to do call back functions for task module
* 
*   ver 1.0    28APR2020
*                  - initial version
***************************************************************************/

require_once(dirname(__FILE__)."/../Config/config.php");
if (!class_exists('db_connect')){require_once(dirname(__FILE__)."/../../".$db_connect_path);}

?>