<?php
/*database connection path*/
$db_connect_path = 'config/db_connect.php';

?>