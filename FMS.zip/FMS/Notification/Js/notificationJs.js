function DeleteNotification(value)
{
		$.ajax({
		type: "POST",
		url: '../Notification/Action/manageNotificationAction.php',
		data:{'delete_notification_staff_id':value},
		success: function(res){
			if(res >0){

					 $('#refreshNotification').load(document.URL + ' #refreshNotification');		
						}
						else{
							
						}
	}
	});
}
function DeleteNotificationSingle(value)
{
		$.ajax({
		type: "POST",
		url: '../Notification/Action/manageNotificationAction.php',
		data:{'delete_notification':value},
		success: function(res){
			if(res >0){
				location.href = "../public/messages-view_all_messages";
						
						}
						else{
							location.href = "../public/messages-view_all_messages";
						}
	}
	});
}