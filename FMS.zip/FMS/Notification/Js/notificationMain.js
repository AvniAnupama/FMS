var table;
$(document).ready(function()
{
	table=$('#example').DataTable(
	{
		dom: 'Bfrtip',
		buttons: [
			'copy', 'excel', 'pdf', 'print'
		],
		"order": [],
		"pageLength": 100
	} );

} );



function DeleteAllNotification(val)
{
	var FormAction='Action/manageNotificationAction.php';
	swal({
	title: "Are you sure?",
	text: "Do you want mark this as read!",
	icon: "warning",
	buttons: true,
	dangerMode: true,
	})
	.then((willDelete) => {
	if (willDelete) {
		$.ajax({
		type: "POST",
		url: FormAction,
		data:{'delete_notification_staff_id':val},
		success: function(res){
			if(res >0){
							
							 swal(
                            'Done!',
                            'Status: Successfully Completed your process',
                            'success'
                        )
						table.clear().draw();
						}
						else{
							window.isSubmitted = false;
							swal(
                            'Failed!',
                            'Status Please try again',
                            'error'
                        );
						}
	}
	});
	} 
	else {
			swal("Your imaginary file is safe!");
		  }
	});
}
function DeleteNotification(val,index)
{
	var FormAction='Action/manageNotificationAction.php';
	swal({
	title: "Are you sure?",
	text: "Do you want mark this as read!",
	icon: "warning",
	buttons: true,
	dangerMode: true,
	})
	.then((willDelete) => {
	if (willDelete) {
		$.ajax({
		type: "POST",
		url: FormAction,
		data:{'delete_notification':val},
		success: function(res){
			if(res == "1"){
							
							 swal(
                            'Done!',
                            'Status: Successfully Completed your process',
                            'success'
                        )
						table.row(index).remove().draw();
						}
						else{
							window.isSubmitted = false;
							swal(
                            'Failed!',
                            'Status Please try again',
                            'error'
                        );
						}
	}
	});
	} 
	else {
			swal("Your imaginary file is safe!");
		  }
	});
}






