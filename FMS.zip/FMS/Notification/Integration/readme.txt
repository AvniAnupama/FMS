This is for showing notification on the top


1) sb-admin.css included one style for notification replace it in Anlon\1Assets\css.

2) nav bar included notification icon and count  replace in Anlon\Common\page

3) tbl_notification_main.sql to be uplaoded inthe database
