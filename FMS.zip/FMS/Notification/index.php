<?php  
/***************************************************************************
*  Objective: html page to manage stack assign task to my subordinates
* 
*   ver 1.0    29APR2020
*                  - initial version
***************************************************************************/
session_start();
require_once('Config/config.php');
require_once '../Common/generic_functions.php';
require_once "../".$db_connect_path;
$obj 	= new db_connect;
require_once('../Common/page/head.php');
require_once('../Common/page/navbar.php');
require_once('../Common/page/cssa_topbar.php');
?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<div class="row">
	<div class="col-lg-12">
	<h3 class="page-header"><b>All Notification</b></h3>
		<ol class="breadcrumb">
			<li><i class="fa fa-home"></i>  <a href="../Login/welcome.php">Home</a> </li>
			<li class="active"> <i class="fa fa-tasks"></i>All  Notification </li>
		</ol>
	</div>
</div>
<div class="row">
<div class="col-md-12">
<h4 class="page-header"><b>Notification</b></h4>
<div style="overflow-x:auto;">
<button onclick="DeleteAllNotification(<?=$_SESSION['Id'];?>);" class="btn btn-warning pull-right"><i class="fa fa-check" aria-hidden="true"></i> Mark all as read</button>
<br><br>
<table class="table table-bordered" id="example">
    <thead>
      <tr>
        <th>Si No</th>
		<th>Title</th>
        <th>Details</th>
        <th>Created Date</th>
		<th>Mark as read</th>
      </tr>
    </thead>
    <tbody>
	<?php
	/*if mange need to varify all taskes we can use the commented script*/
	$GetNotification=$obj->select_any("tbl_notification_main","staff_id='".$_SESSION['Id']."' order by notification_main_id DESC");
			
	$indexOftable=0;
	foreach($GetNotification as $GetNotificationSingle)
	{
	?>
       <tr>
        <td><?=$indexOftable+1;?> </td>  
		<td><?=$GetNotificationSingle['title'];?> </td> 
		
        <td><?=$GetNotificationSingle['details'];?> </td> 
		
        <td><?=date('d-m-Y',strtotime($GetNotificationSingle['createdDate']));?></td>
        <th><button onclick="DeleteNotification(<?=$GetNotificationSingle['notification_main_id'];?>,<?=$indexOftable;?>);" class="btn btn-danger"><i class="fa fa-check-circle" aria-hidden="true"></i>Mark as Read</button></th>
	</tr>
    <?php
	$indexOftable++;
	}
	?>
    </tbody>
  </table>
</div></div>
</div>
<hr>

<script src="Js/notificationMain.js"></script>
<?php
require_once('../Common/page/footer.php');
?>

