		   <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="Home">Dashboard</a></li>
						<li class="breadcrumb-item"><a href="manage work"><?=ucwords('manage work');?></a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)"><?=ucwords('Allocate Work');?></a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->
			<div class="container-fluid">
				
				<div class="row">
					 <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><?=ucwords('Allocate Work');?></h4>
                                
                                <div class="basic-form" >
								
                                    <form enctype="multipart/form-data"  method="POST"  action="../manage work/Action/Actionmanage_work_allocate_work.php">
										<div id="UserFormUpdate">
										<?php
										if(isset($_GET['edit_id']))
										{
											$formDataEdit=$obj->select_any_one("tbl_manage_work_allocate_work","manage_work_allocate_work_id='".$_GET['edit_id']."'");
										}
										?>
										
<div class="form-group">
<label>work title:</label>
<input required type="text" name="work_title" value="<?=(isset($formDataEdit['work_title']))?$formDataEdit['work_title']:'';?>" class="form-control input-default">
</div>
<div class="form-group">
<label>work details:</label>
<textarea  name="work_details"  class="form-control input-default"><?=(isset($formDataEdit['work_details']))?$formDataEdit['work_details']:'';?></textarea>
</div>

<div class="form-group">
<label>allocate work to employee:</label>
<select required class="form-control input-default" name="allocate_work_to_employee">
<option value="">Choose your option</option>
<?php
$allocate_work_to_employee_data=$obj->select_any("tbl_manage_employee_add_new_employee","1");
foreach($allocate_work_to_employee_data as $allocate_work_to_employee_data_single)
{
?>
<option <?=(isset($formDataEdit))?(($formDataEdit['allocate_work_to_employee']==$allocate_work_to_employee_data_single['manage_employee_add_new_employee_id'])?'selected':''):'';?> value="<?=$allocate_work_to_employee_data_single['manage_employee_add_new_employee_id'];?>"><?=$allocate_work_to_employee_data_single['name'];?></option>
<?php	
}
?>
</select>
</div>

<div class="form-group">
<label>work date:</label>
<input  value="<?=(isset($formDataEdit['work_date']))?$formDataEdit['work_date']:'';?>"  type="date" name="work_date"  class="form-control input-default">
</div>
<div class="form-group">
<label>allocated time for work:</label>
<input  type="text" name="allocated_time_for_work" value="<?=(isset($formDataEdit['allocated_time_for_work']))?$formDataEdit['allocated_time_for_work']:'';?>" class="form-control input-default">
</div>
										<?php
										if(isset($_GET['edit_id']))
										{
											?>
												<input type="hidden" value="<?=(isset($formDataEdit['manage_work_allocate_work_id']))?$formDataEdit['manage_work_allocate_work_id']:'';?>"  name="update">
									
											<?php
										}
										else
										{
											?>
												<input type="hidden" name="Save">
											<?php
										}
										?>
									</div>
									<div class="form-group">
<label>work status:</label>
<select  class="form-control input-default" name="work_status">
<option value="">Choose your option</option>
<?php
$work_status_data=$obj->select_any("tbl_manage_work_allocate_work_work_status","1");
foreach($work_status_data as $work_status_data_single)
{
?>
<option <?=(isset($formDataEdit))?(($formDataEdit['work_status']==$work_status_data_single['value'])?'selected':''):'';?> value="<?=$work_status_data_single['manage_work_allocate_work_work_status_id'];?>"><?=$work_status_data_single['value'];?></option>
<?php	
}
?>
</select>
</div>
									<button type="submit"  class="btn btn-dark">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
					
				</div>
				
				<div class="row">
						 <div class="col-lg-12">
						   <div class="card" style="overflow-x:auto;">
								<div class="card-body" id="UserTable">
									<h4 class="card-title">Table</h4>
										<table id="example" class="display nowrap" cellspacing="0" width="100%">
											<thead>
												<tr>
												<th>Si No</th>
													
<th>work title</th>
<th>work details</th>
<th>allocate work to employee</th>
<th>work status</th>
<th>work date</th>
<th>allocated time for work</th><th>Edit</th>
<th>Delete</th>
												</tr>
											</thead>
											<tbody>
											<?php
											$formDataFull=$obj->select_any("tbl_manage_work_allocate_work","1 order by manage_work_allocate_work_id DESC");
											$count=1;
											if(!empty($formDataFull))
											{
											foreach($formDataFull as $formDataSingle)
											{
											
											?>
											<tr>
											<td><?=$count;?></th>
											
<td><?=$formDataSingle['work_title'];?></td>
<td><?=$formDataSingle['work_details'];?></td>
<?php
$allocate_work_to_employee=$obj->select_any_one("tbl_manage_employee_add_new_employee","manage_employee_add_new_employee_id='".$formDataSingle['allocate_work_to_employee']."'");
?>
<td><?=$allocate_work_to_employee['name'];?></td>
<?php
$work_status=$obj->select_any_one("tbl_manage_work_allocate_work_work_status","".str_replace('tbl_','','tbl_manage_work_allocate_work')."_work_status_id='".$formDataSingle['work_status']."'");
?>
<td><?=$work_status['value'];?></td>
<td><?=$formDataSingle['work_date'];?></td>
<td><?=$formDataSingle['allocated_time_for_work'];?></td>	<td><a href="?edit_id=<?=$formDataSingle['manage_work_allocate_work_id'];?>"><i class="fa fa-edit color-danger"></i></a></td>
	<td><a href="../manage work/Action/Actionmanage_work_allocate_work.php?manage_work_allocate_work_id=<?=$formDataSingle['manage_work_allocate_work_id'];?>"><i class="fa fa-close color-danger"></i></a></td>
											</tr>
											<?php
											$count++;
											}
											}
											?>
											</tbody>
										</table>

								</div>
							</div>
						</div>
				</div>
				
			</div>
            <!-- #/ container -->
        </div>
		
        <!--**********************************
            Content body end
        ***********************************--> 
		<script>
		var IndexIncrement=<?=count($formDataFull);?>
		</script>