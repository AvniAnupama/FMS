<?php
require_once"../../config/db_connect.php";
$obj=new db_connect;
$tableName="tbl_manage_work_allocate_work";
//print_r($_REQUEST);
if(isset($_REQUEST['Save']))
{
	unset($_REQUEST['Save']);
	
	
	$result=$obj->inserttblReturnId($_REQUEST,$tableName);
	if($result>0)
   {
		header("location:../../public/manage_work-allocate_work?result=1");
	}
	else
	{
		header("location:../../public/manage_work-allocate_work?result=0");
	}
}
if(isset($_REQUEST['update']))
{
	$con=array('manage_work_allocate_work_id'=>$_REQUEST['update']);
	unset($_REQUEST['update']);
	
	
	$result=$obj->updatetbl($_REQUEST,$tableName,$con);
	if($result>0)
	{
		header("location:../../public/manage_work-allocate_work?result=1");
	}
	else
	{
		header("location:../../public/manage_work-allocate_work?result=0");
	}
}
if(isset($_REQUEST['manage_work_allocate_work_id']))
{
	$condition="manage_work_allocate_work_id='".$_REQUEST['manage_work_allocate_work_id']."'";
	
	$result=$obj->tbl_delete($tableName,$condition);
	if($result==1)
	{
		header("location:../../public/manage_work-allocate_work?result=1");
	}
	else
	{
		header("location:../../public/manage_work-allocate_work?result=0");
	}
}
?>