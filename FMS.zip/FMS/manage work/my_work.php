		   <!--**********************************
            Content body start
        ***********************************-->
		<?php
		
$tableName="tbl_manage_work_allocate_work";
		if(isset($_GET['start_work']))
		{
			$con=array('manage_work_allocate_work_id'=>$_GET['start_work']);
		
	$data=array('work_status'=>2);
	$result=$obj->updatetbl($data,$tableName,$con);
		}if(isset($_GET['end_work']))
		{
			$con=array('manage_work_allocate_work_id'=>$_GET['end_work']);
		
	$data=array('work_status'=>3);
	$result=$obj->updatetbl($data,$tableName,$con);
		}
		?>
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="Home">Dashboard</a></li>
						<li class="breadcrumb-item"><a href="manage-work"><?=ucwords('manage work');?></a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Start Work</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->
			<div class="container-fluid">
				
			
				
				<div class="row">
						 <div class="col-lg-12">
						   <div class="card" style="overflow-x:auto;">
								<div class="card-body" id="UserTable">
									<h4 class="card-title">Table</h4>
										<table id="example" class="display nowrap" cellspacing="0" width="100%">
											<thead>
												<tr>
												<th>Si No</th>
<th>Action</th>													
<th>work title</th>
<th>work details</th>
<th>allocate work to employee</th>
<th>work status</th>
<th>work date</th>
<th>allocated time for work</th>

												</tr>
											</thead>
											<tbody>
											<?php
											$formDataFull=$obj->select_any("tbl_manage_work_allocate_work","allocate_work_to_employee=".$_SESSION['user_id']." and work_status!='3' order by manage_work_allocate_work_id DESC");
											$count=1;
											if(!empty($formDataFull))
											{
											foreach($formDataFull as $formDataSingle)
											{
											
											?>
											<tr>
											<td><?=$count;?></th>
<td>
<?php
if($formDataSingle['work_status']==2)
{
	?>
	<a class="btn btn-danger" href="?end_work=<?=$formDataSingle['manage_work_allocate_work_id'];?>">Complete work</a>
	<?php
}
else
{
?>
<a class="btn btn-success" href="?start_work=<?=$formDataSingle['manage_work_allocate_work_id'];?>">Start work</a>	<?php
}
?>
</td>
<td><?=$formDataSingle['work_title'];?></td>
<td><?=$formDataSingle['work_details'];?></td>
<?php
$allocate_work_to_employee=$obj->select_any_one("tbl_manage_employee_add_new_employee","manage_employee_add_new_employee_id='".$formDataSingle['allocate_work_to_employee']."'");
?>
<td><?=$allocate_work_to_employee['name'];?></td>
<?php
$work_status=$obj->select_any_one("tbl_manage_work_allocate_work_work_status","".str_replace('tbl_','','tbl_manage_work_allocate_work')."_work_status_id='".$formDataSingle['work_status']."'");
?>
<td><?=$work_status['value'];?></td>
<td><?=$formDataSingle['work_date'];?></td>
<td><?=$formDataSingle['allocated_time_for_work'];?></td>
											</tr>
											<?php
											$count++;
											}
											}
											?>
											</tbody>
										</table>

								</div>
							</div>
						</div>
				</div>
				
			</div>
            <!-- #/ container -->
        </div>
		
        <!--**********************************
            Content body end
        ***********************************--> 
		<script>
		var IndexIncrement=<?=count($formDataFull);?>
		</script>