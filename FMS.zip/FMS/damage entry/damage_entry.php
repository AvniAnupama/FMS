		   <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="Home">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">damage entry</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
				 <div class="container-fluid">
				<div class="row">
				<div class="col-lg-3 col-sm-6" onclick="location.href='damage_entry_manage_damage.php'">
								<div class="card gradient-3">
									<div class="card-body">
										<center>
										<h3 class="card-title text-white">Manage damage</h3>
										
											<h2 class="text-white"><i class="fa fa-book"></i></h2>
											
										</center>
										
									</div>
								</div>
							</div>
				</div>
			</div>
				
			</div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->  
