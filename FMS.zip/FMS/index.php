<?php
header("location:public/login.php")
?>