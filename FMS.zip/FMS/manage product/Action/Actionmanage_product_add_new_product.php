<?php
require_once"../../config/db_connect.php";
$obj=new db_connect;
$tableName="tbl_manage_product_add_new_product";
//print_r($_REQUEST);
if(isset($_REQUEST['Save']))
{
	unset($_REQUEST['Save']);
	if(!isset($_FILES['product_image']) || $_FILES['product_image']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['product_image']=$_REQUEST['product_image_file_dummy'];
	   unset($_REQUEST['product_image_file_dummy']);
		} else {
		
							$imgTp=$_FILES["product_image"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['product_image']['name'];
							$path="../manage product/Files/";//folder name is users
							$img=$_FILES['product_image']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['product_image']=$pathname;
							if($_REQUEST['product_image_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['product_image_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['product_image']='';
							 
							}
		}
		unset($_REQUEST['product_image_file_dummy']);
	
	$result=$obj->inserttblReturnId($_REQUEST,$tableName);
	if($result>0)
   {
		header("location:../../public/manage_product-add_new_product?result=1");
	}
	else
	{
		header("location:../../public/manage_product-add_new_product?result=0");
	}
}
if(isset($_REQUEST['update']))
{
	$con=array('manage_product_add_new_product_id'=>$_REQUEST['update']);
	unset($_REQUEST['update']);
	if(!isset($_FILES['product_image']) || $_FILES['product_image']['error'] == UPLOAD_ERR_NO_FILE) {
	   $_REQUEST['product_image']=$_REQUEST['product_image_file_dummy'];
	   unset($_REQUEST['product_image_file_dummy']);
		} else {
		
							$imgTp=$_FILES["product_image"]["type"];
							$ret=rand('20','40000001111111111111111111');
							$rnam=$_FILES['product_image']['name'];
							$path="../manage product/Files/";//folder name is users
							$img=$_FILES['product_image']['tmp_name'];//upimage is image field
							$name=$ret. microtime() .$rnam;
							if(move_uploaded_file($img,"../".$path.$name))
							{
							$pathname="$path$name";
							$_REQUEST['product_image']=$pathname;
							if($_REQUEST['product_image_file_dummy']!='')
							{
							 unlink("../".$_REQUEST['product_image_file_dummy']);	
							}
							}
							else
							{
							$_REQUEST['product_image']='';
							 
							}
		}
		unset($_REQUEST['product_image_file_dummy']);
	
	$result=$obj->updatetbl($_REQUEST,$tableName,$con);
	if($result>0)
	{
		header("location:../../public/manage_product-add_new_product?result=1");
	}
	else
	{
		header("location:../../public/manage_product-add_new_product?result=0");
	}
}
if(isset($_REQUEST['manage_product_add_new_product_id']))
{
	$condition="manage_product_add_new_product_id='".$_REQUEST['manage_product_add_new_product_id']."'";
	$oldDate=$obj->select_any_one($tableName,$condition);
	if($oldDate['product_image']!='')
	{
		unlink("../".$oldDate['product_image']);
	}
	$result=$obj->tbl_delete($tableName,$condition);
	if($result==1)
	{
		header("location:../../public/manage_product-add_new_product?result=1");
	}
	else
	{
		header("location:../../public/manage_product-add_new_product?result=0");
	}
}
?>